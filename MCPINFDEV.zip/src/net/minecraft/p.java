
package net.minecraft;

import java.awt.image.BufferedImage;

public interface p {

    BufferedImage a(final BufferedImage bufferedImage);
}
