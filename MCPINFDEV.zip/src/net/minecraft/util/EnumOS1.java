
package net.minecraft.util;

public enum EnumOS1 {
    linux,
    solaris,
    windows,
    macos,
    unknown;
}
