
package net.minecraft;

public class MinecraftError extends Error {
}
