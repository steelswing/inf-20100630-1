
package net.minecraft.world.gen;

import java.util.Random;
import net.minecraft.world.World;

public abstract class WorldGenerator {

    public abstract boolean generate(final World fe, final Random random, final int integer3, final int integer4, final int integer5);

    public void func_517_a(final double double1, final double double2, final double double3) {
    }
}
