
package net.minecraft;

import java.awt.image.BufferedImage;

public class ei {

    public BufferedImage a;
    public int b;
    public int c;
    public boolean d;

    public ei(final String string, final p p) {
        this.b = 1;
        this.c = -1;
        this.d = false;
        new fm(this, string, p).start();
    }
}
