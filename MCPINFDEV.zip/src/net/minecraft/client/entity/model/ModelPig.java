
package net.minecraft.client.entity.model;

public class ModelPig extends ModelQuadruped {

    public ModelPig() {
        super(6, 0.0f);
    }

    public ModelPig(final float float1) {
        super(6, float1);
    }
}
