
package net.minecraft.client.settings;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.PrintWriter;
import net.minecraft.Minecraft;
import org.lwjgl.input.Keyboard;

public class GameSettings {

    private static final String[] RENDER_DISTANCES;
    private static final String[] DIFFICULTIES;
    public boolean music;
    public boolean sound;
    public boolean invertMouse;
    public boolean showDebugInfo;
    public int renderDistance;
    public boolean viewBobbing;
    public boolean anaglyph;
    public boolean limitFramerate;
    public boolean fancyGraphics;
    public KeyBinding keyBindForward;
    public KeyBinding keyBindLeft;
    public KeyBinding keyBindBack;
    public KeyBinding keyBindRight;
    public KeyBinding keyBindJump;
    public KeyBinding keyBindInventory;
    public KeyBinding keyBindDrop;
    public KeyBinding keyBindChat;
    public KeyBinding keyBindToggleFog;
    public KeyBinding keyBindSave;
    public KeyBinding keyBindLoad;
    public KeyBinding[] keyBindings;
    protected Minecraft mc;
    private final File optionsFile;
    public int numberOfOptions;
    public int difficulty;
    public boolean thirdPersonView;

    static {
        RENDER_DISTANCES = new String[]{"FAR", "NORMAL", "SHORT", "TINY"};
        DIFFICULTIES = new String[]{"Peaceful", "Easy", "Normal", "Hard"};
    }

    public GameSettings(final Minecraft aw, final File file) {
        this.music = true;
        this.sound = true;
        this.invertMouse = false;
        this.showDebugInfo = false;
        this.renderDistance = 0;
        this.viewBobbing = true;
        this.anaglyph = false;
        this.limitFramerate = false;
        this.fancyGraphics = true;
        this.keyBindForward = new KeyBinding("Forward", 17);
        this.keyBindLeft = new KeyBinding("Left", 30);
        this.keyBindBack = new KeyBinding("Back", 31);
        this.keyBindRight = new KeyBinding("Right", 32);
        this.keyBindJump = new KeyBinding("Jump", 57);
        this.keyBindInventory = new KeyBinding("Inventory", 23);
        this.keyBindDrop = new KeyBinding("Drop", 16);
        this.keyBindChat = new KeyBinding("Chat", 20);
        this.keyBindToggleFog = new KeyBinding("Toggle fog", 33);
        this.keyBindSave = new KeyBinding("Save location", 28);
        this.keyBindLoad = new KeyBinding("Load location", 19);
        this.keyBindings = new KeyBinding[]{this.keyBindForward, this.keyBindLeft, this.keyBindBack, this.keyBindRight, this.keyBindJump, this.keyBindDrop, this.keyBindInventory, this.keyBindChat, this.keyBindToggleFog, this.keyBindSave, this.keyBindLoad};
        this.numberOfOptions = 10;
        this.difficulty = 2;
        this.thirdPersonView = false;
        this.mc = aw;
        this.optionsFile = new File(file, "options.txt");
        this.loadOptions();
    }

    public String getOptionDisplayString(final int integer) {
        return this.keyBindings[integer].keyDescription + ": " + Keyboard.getKeyName(this.keyBindings[integer].keyCode);
    }

    public void setKeyBinding(final int integer1, final int integer2) {
        this.keyBindings[integer1].keyCode = integer2;
        this.saveOptions();
    }

    public void setOptionFloatValue(final int integer1, final int integer2) {
        if (integer1 == 0) {
            this.music = !this.music;
            this.mc.sndManager.onSoundOptionsChanged();
        }
        if (integer1 == 1) {
            this.sound = !this.sound;
            this.mc.sndManager.onSoundOptionsChanged();
        }
        if (integer1 == 2) {
            this.invertMouse = !this.invertMouse;
        }
        if (integer1 == 3) {
            this.showDebugInfo = !this.showDebugInfo;
        }
        if (integer1 == 4) {
            this.renderDistance = (this.renderDistance + integer2 & 0x3);
        }
        if (integer1 == 5) {
            this.viewBobbing = !this.viewBobbing;
        }
        if (integer1 == 6) {
            this.anaglyph = !this.anaglyph;
            this.mc.renderEngine.refreshTextures();
        }
        if (integer1 == 7) {
            this.limitFramerate = !this.limitFramerate;
        }
        if (integer1 == 8) {
            this.difficulty = (this.difficulty + integer2 & 0x3);
        }
        if (integer1 == 9) {
            this.fancyGraphics = !this.fancyGraphics;
            this.mc.renderGlobal.fancyGraphics();
        }
        this.saveOptions();
    }

    public String getKeyBinding(final int integer) {
        if (integer == 0) {
            return new StringBuilder().append("Music: ").append(this.music ? "ON" : "OFF").toString();
        }
        if (integer == 1) {
            return new StringBuilder().append("Sound: ").append(this.sound ? "ON" : "OFF").toString();
        }
        if (integer == 2) {
            return new StringBuilder().append("Invert mouse: ").append(this.invertMouse ? "ON" : "OFF").toString();
        }
        if (integer == 3) {
            return new StringBuilder().append("Show FPS: ").append(this.showDebugInfo ? "ON" : "OFF").toString();
        }
        if (integer == 4) {
            return "Render distance: " + GameSettings.RENDER_DISTANCES[this.renderDistance];
        }
        if (integer == 5) {
            return new StringBuilder().append("View bobbing: ").append(this.viewBobbing ? "ON" : "OFF").toString();
        }
        if (integer == 6) {
            return new StringBuilder().append("3d anaglyph: ").append(this.anaglyph ? "ON" : "OFF").toString();
        }
        if (integer == 7) {
            return new StringBuilder().append("Limit framerate: ").append(this.limitFramerate ? "ON" : "OFF").toString();
        }
        if (integer == 8) {
            return "Difficulty: " + GameSettings.DIFFICULTIES[this.difficulty];
        }
        if (integer == 9) {
            return new StringBuilder().append("Graphics: ").append(this.fancyGraphics ? "FANCY" : "FAST").toString();
        }
        return "";
    }

    public void loadOptions() {
        try {
            if (!this.optionsFile.exists()) {
                return;
            }
            try (BufferedReader bufferedReader = new BufferedReader(new FileReader(this.optionsFile))) {
                String line;
                while ((line = bufferedReader.readLine()) != null) {
                    final String[] split = line.split(":");
                    if (split[0].equals("music")) {
                        this.music = split[1].equals("true");
                    }
                    if (split[0].equals("sound")) {
                        this.sound = split[1].equals("true");
                    }
                    if (split[0].equals("invertYMouse")) {
                        this.invertMouse = split[1].equals("true");
                    }
                    if (split[0].equals("showFrameRate")) {
                        this.showDebugInfo = split[1].equals("true");
                    }
                    if (split[0].equals("viewDistance")) {
                        this.renderDistance = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("bobView")) {
                        this.viewBobbing = split[1].equals("true");
                    }
                    if (split[0].equals("anaglyph3d")) {
                        this.anaglyph = split[1].equals("true");
                    }
                    if (split[0].equals("limitFramerate")) {
                        this.limitFramerate = split[1].equals("true");
                    }
                    if (split[0].equals("difficulty")) {
                        this.difficulty = Integer.parseInt(split[1]);
                    }
                    if (split[0].equals("fancyGraphics")) {
                        this.fancyGraphics = split[1].equals("true");
                    }
                    for (int i = 0; i < this.keyBindings.length; ++i) {
                        if (split[0].equals(("key_" + this.keyBindings[i].keyDescription))) {
                            this.keyBindings[i].keyCode = Integer.parseInt(split[1]);
                        }
                    }
                }
            }
        } catch (Exception ex) {
            System.out.println("Failed to load options");
            ex.printStackTrace();
        }
    }

    public void saveOptions() {
        try {
            try (PrintWriter printWriter = new PrintWriter(new FileWriter(this.optionsFile))) {
                printWriter.println(new StringBuilder().append("music:").append(this.music).toString());
                printWriter.println(new StringBuilder().append("sound:").append(this.sound).toString());
                printWriter.println(new StringBuilder().append("invertYMouse:").append(this.invertMouse).toString());
                printWriter.println(new StringBuilder().append("showFrameRate:").append(this.showDebugInfo).toString());
                printWriter.println(new StringBuilder().append("viewDistance:").append(this.renderDistance).toString());
                printWriter.println(new StringBuilder().append("bobView:").append(this.viewBobbing).toString());
                printWriter.println(new StringBuilder().append("anaglyph3d:").append(this.anaglyph).toString());
                printWriter.println(new StringBuilder().append("limitFramerate:").append(this.limitFramerate).toString());
                printWriter.println(new StringBuilder().append("difficulty:").append(this.difficulty).toString());
                printWriter.println(new StringBuilder().append("fancyGraphics:").append(this.fancyGraphics).toString());
                for (int i = 0; i < this.keyBindings.length; ++i) {
                    printWriter.println("key_" + this.keyBindings[i].keyDescription + ":" + this.keyBindings[i].keyCode);
                }
            }
        } catch (Exception ex) {
            System.out.println("Failed to save options");
            ex.printStackTrace();
        }
    }

}
