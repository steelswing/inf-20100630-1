
package net.minecraft.client.gui;

public class GuiSmallButton extends GuiButton {

    public GuiSmallButton(final int integer1, final int integer2, final int integer3, final String string) {
        super(integer1, integer2, integer3, 150, 20, string);
    }
}
