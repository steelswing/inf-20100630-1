
package net.minecraft.client.renderer.entity;

import net.minecraft.block.Block;
import net.minecraft.entity.EntityFallingSand;
import net.minecraft.util.MathHelper;
import net.minecraft.world.World;
import org.lwjgl.opengl.GL11;

public class RenderFallingSand extends Render<EntityFallingSand> {

    private RenderBlocks field_197_d;

    public RenderFallingSand() {
        this.field_197_d = new RenderBlocks();
        this.shadowSize = 0.5f;
    }

    public void doRender(final EntityFallingSand entityLiving, final double xCoord, final double sqrt_double, final double yCoord, final float nya1, final float nya2) {
        GL11.glPushMatrix();
        GL11.glTranslatef((float) xCoord, (float) sqrt_double, (float) yCoord);
        this.loadTexture("/terrain.png");
        final Block gs = Block.blocksList[entityLiving.blockID];
        final World world = entityLiving.getWorld();
        GL11.glDisable(2896);
        this.field_197_d.renderBlockFallingSand(gs, world, MathHelper.floor_double(entityLiving.posX), MathHelper.floor_double(entityLiving.posY), MathHelper.floor_double(entityLiving.posZ));
        GL11.glEnable(2896);
        GL11.glPopMatrix();
    }
}
